<?php $__env->startSection('content'); ?>
    ini profile
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend/layout/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\RPL_24\latihan\resources\views/backend/content/profile.blade.php ENDPATH**/ ?>